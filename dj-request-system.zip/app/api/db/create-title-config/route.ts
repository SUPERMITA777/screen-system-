import { NextResponse } from "next/server"
import { getSupabaseServer } from "@/lib/supabase"

export async function GET() {
  try {
    const supabase = getSupabaseServer()

    // SQL para crear la tabla e insertar datos por defecto
    const sql = `
    CREATE TABLE IF NOT EXISTS public.title_config (
      id SERIAL PRIMARY KEY,
      text TEXT NOT NULL DEFAULT 'INTERACTIVE SCREEN & MUSIC',
      image_url TEXT,
      left_image_url TEXT,
      right_image_url TEXT,
      enabled BOOLEAN DEFAULT TRUE,
      image_size_percent INTEGER DEFAULT 80,
      is_static BOOLEAN DEFAULT FALSE
    );
    
    -- Insertar configuración por defecto si la tabla está vacía
    INSERT INTO public.title_config (id, text, enabled, image_size_percent, is_static)
    SELECT 1, 'INTERACTIVE SCREEN & MUSIC', TRUE, 80, FALSE
    WHERE NOT EXISTS (SELECT 1 FROM public.title_config WHERE id = 1);
    `

    // Ejecutar SQL directamente usando la función exec_sql
    const { error } = await supabase.rpc("exec_sql", { sql })

    if (error) {
      console.error("Error al ejecutar SQL:", error)
      return NextResponse.json(
        {
          success: false,
          error: "No se pudo crear la tabla title_config",
          details: error,
        },
        { status: 500 },
      )
    }

    return NextResponse.json({
      success: true,
      message: "Tabla title_config creada correctamente",
    })
  } catch (error) {
    console.error("Error en la API:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Error interno del servidor",
        details: error,
      },
      { status: 500 },
    )
  }
}

